UAS kelompok 2
- Abdul Aziz Setiawan 20200801072
- Enggar Lanang N A G 20200801076
- Alfariesta Chandra P 20200801092
- Jessica Inamora 20200801067
